package edf.fr.tegg.utils;


public class Cs2csException extends Exception {
    public Cs2csException(String message) {
        super(message);
    }
}