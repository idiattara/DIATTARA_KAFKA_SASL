package edf.fr.tegg.cs2cs;

import edf.fr.tegg.cs2cs.procesor.CoordinateTransformerProcesor;
import org.apache.nifi.util.MockFlowFile;
import org.apache.nifi.util.TestRunner;
import org.apache.nifi.util.TestRunners;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class CoordinateTransformerProcesorTest  {

    private TestRunner testRunner;

    @Before
    public void init() {
        testRunner = TestRunners.newTestRunner(CoordinateTransformerProcesor.class);
    }

    @Test
    public void testProcessorSuccess() {
        // Configuration du processeur
        testRunner.setValidateExpressionUsage(false);
        testRunner.setProperty(CoordinateTransformerProcesor.PARAMS, "50.12;46.13;VIDE;2154;4326");

        // Ajouter des données à l'entrée
        testRunner.enqueue("some data");

        // Exécuter le processeur
        testRunner.run();

        // Vérifier si le processeur a produit une sortie
        testRunner.assertTransferCount(CoordinateTransformerProcesor.SUCCESS, 1);

        // Récupérer le contenu du FlowFile de sortie
        MockFlowFile mockFlowFile = testRunner.getFlowFilesForRelationship(CoordinateTransformerProcesor.SUCCESS).get(0);
        String outputContent = new String(mockFlowFile.toByteArray());
        // Vérifier le contenu de la sortie
        assertEquals("-1,3627853;-5,9835518;null", outputContent);
                //.replaceAll("[\\r\\n\\s]+", "").trim());
    }



}





