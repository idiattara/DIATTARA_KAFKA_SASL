
#!/bin/bash
set -e

python3 get_lines.py $1 $2


