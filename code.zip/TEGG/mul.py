import concurrent.futures
from neo4j import GraphDatabase

uri = "bolt://dceyy3a6.noe.edf.fr:7687"
username = "neo4j"
password = "password"
database_name = "teggtestbrute"
file_path = "/run/tmp_data/result_lines/data/886c63ea-b56f-4dbf-b2e6-10b65ca13e95"

# Fonction pour exécuter une transaction
def execute_transaction(queries):
    with GraphDatabase.driver(uri, auth=(username, password), database=database_name) as driver:
        with driver.session() as session:
            transaction = session.begin_transaction()
            for query in queries:
                transaction.run(query)
            transaction.commit()

# Charger les requêtes depuis le fichier
with open(file_path, 'r') as file:
    queries = [query for query in file.readlines()]

# Utilisation du multiprocessing pour exécuter les requêtes en parallèle
batch_size = 500 # Ajustez selon vos besoins
#num_process = 10=max_workers
with concurrent.futures.ProcessPoolExecutor() as executor:
    query_batches = [queries[i:i + batch_size] for i in range(0, len(queries), batch_size)]
    executor.map(execute_transaction, query_batches)
