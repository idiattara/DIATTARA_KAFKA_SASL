#!/bin/bash

# Vérifiez si un seul argument a été fourni
if [ $# -ne 1 ]; then
    exit 1
fi

# Récupérez l'argument de la ligne de commande
conversion="$1"

# Utilisez awk pour extraire la valeur, l'unité de base et l'unité cible
value=$(echo "$conversion" | awk '{print $1}')
unit_base=$(echo "$conversion" | awk '{print $2}')
unit_target=$(echo "$conversion" | awk '{print $4}')

# Utilisez la commande "units" pour effectuer la conversion et stockez la sortie dans une variable
result=$(units -t "$value$unit_base" "$unit_target")
# Utilisez awk pour extraire la valeur numérique
#numeric_result=$(echo "$result" | awk 'NR==2{print $2}')
echo "$result"
