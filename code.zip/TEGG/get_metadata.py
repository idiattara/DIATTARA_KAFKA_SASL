import json
import sys

filename=sys.argv[2]
pathstore=sys.argv[1]

with open(pathstore+filename, 'r') as fichier_json:
    data = json.load(fichier_json)

metadata = data.get('metadata', {})

with open(pathstore+'result_metadata/'+filename, 'w') as fichier_resultat:
    fichier_resultat.write(json.dumps(metadata, indent=2))

print("OK")
