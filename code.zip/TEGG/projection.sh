
#!/bin/bash
# Author: Karim

set -e

X="$1"
Y="$2"
Z="$3"

BASE_SYSTEM="$4"
TARGET_SYSTEM="$5"

echo $X $Y $Z | cs2cs +init=$BASE_SYSTEM +to +init=$TARGET_SYSTEM -f "%.10f"


