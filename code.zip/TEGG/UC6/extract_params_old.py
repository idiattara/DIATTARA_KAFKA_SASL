

from obspy import read
import sys

sourceFile = read(sys.argv[1])

network = sourceFile[0].stats.network
station = sourceFile[0].stats.station
location = sourceFile[0].stats.location
channel = sourceFile[0].stats.channel
timing = sourceFile[0].stats.starttime.strftime("%Y%m%d_%H%M%S")

print(network +"."+ station +"."+ location +"."+ channel +"."+ timing +".mseed")


