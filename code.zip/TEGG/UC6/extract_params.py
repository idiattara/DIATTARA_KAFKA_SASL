
from obspy import read
import sys

sourceFile = read(sys.argv[1])

network = sourceFile[0].stats.network
station = sourceFile[0].stats.station
location = sourceFile[0].stats.location
channel = sourceFile[0].stats.channel
timing = sourceFile[0].stats.starttime.strftime("%Y%m%d_%H%M%S")

if network =='RA' and station == 'NAG1' and channel[0:2] == 'HH' :
	network ='EF'
	location ='01'

print(network +"."+ station +"."+ location +"."+ channel +"."+ timing +".mseed")


