
#!/bin/bash
set -e

python3 get_metadata.py $1 $2


