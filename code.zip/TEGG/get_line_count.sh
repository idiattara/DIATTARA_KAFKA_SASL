#!/bin/bash
set -e
wc -l  $1 | awk '{print $1}'
