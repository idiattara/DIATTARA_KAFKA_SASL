import org.neo4j.driver.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Neo4jQueryExecutorWithTransaction {

    public static void main(String[] args) {
        String uri = "bolt://dceyy3a6.noe.edf.fr:7687";
        String user = "neo4j";
        String password = "password";
        String databaseName = "teggtestbrute";

        try (Driver driver = GraphDatabase.driver(uri, AuthTokens.basic(user, password))) {

            String filePath = "886c63ea-b56f-4dbf-b2e6-10b65ca13e95";
            List<String> batchQueries = readQueriesFromFile(filePath);

            int batchSize = 2500;
            int numberOfThreads = 20;

            ExecutorService executorService = Executors.newFixedThreadPool(numberOfThreads);

            List<List<String>> queryBatches = splitQueriesIntoBatches(batchQueries, batchSize);

            CountDownLatch latch = new CountDownLatch(queryBatches.size());

            for (List<String> queryBatch : queryBatches) {
                executorService.submit(() -> {
                    executeBatchQueriesWithTransaction(driver, databaseName, queryBatch);
                    latch.countDown();
                });
            }

            // Attendre la fin de toutes les tâches
            latch.await();

            // Fermer le driver après la fin de toutes les tâches
            executorService.shutdown();
            driver.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static List<String> readQueriesFromFile(String filePath) throws IOException {
        List<String> batchQueries = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String query;
            while ((query = br.readLine()) != null) {
                batchQueries.add(query);
            }
        }
        return batchQueries;
    }

    private static List<List<String>> splitQueriesIntoBatches(List<String> allQueries, int batchSize) {
        List<List<String>> queryBatches = new ArrayList<>();
        for (int i = 0; i < allQueries.size(); i += batchSize) {
            int end = Math.min(i + batchSize, allQueries.size());
            queryBatches.add(allQueries.subList(i, end));
        }
        return queryBatches;
    }

    private static void executeBatchQueriesWithTransaction(Driver driver, String databaseName, List<String> batchQueries) {
        try (Session session = driver.session(SessionConfig.builder().withDatabase(databaseName).build())) {
            session.writeTransaction(tx -> {
                for (String query : batchQueries) {
                    executeQuery(tx, query);
                }
                return null;
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void executeQuery(Transaction tx, String query) {
        try {
            Result result = tx.run(query);
            while (result.hasNext()) {
                Record record = result.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
