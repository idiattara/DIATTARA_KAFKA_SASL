
#!/bin/bash
set -e

python2 projection.py $1 $2 $3 $4 $5


