import ijson
import sys
import json
 
filename = sys.argv[2]
pathstore = sys.argv[1]
 
metadata = {}
 
with open(pathstore + filename, 'r') as f:
    parser = ijson.parse(f)
    in_metadata = False
    for prefix, event, value in parser:
        if prefix == 'metadata' and event == 'start_map':
            in_metadata = True
            metadata = {}
        elif in_metadata and event == 'map_key':
            current_key = value
        elif in_metadata and event in ('string', 'number', 'boolean', 'null'):
            metadata[current_key] = value
        elif prefix == 'metadata' and event == 'end_map':
            break  # on a fini la section "metadata"
 
with open(pathstore + 'result_metadata/' + filename, 'w') as f_out:
    f_out.write(json.dumps(metadata, indent=2))
 
print("OK")
