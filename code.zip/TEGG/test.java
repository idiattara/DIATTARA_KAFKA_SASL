import org.neo4j.driver.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Neo4jBulkLoader {

    private static final String URI = "bolt://dceyy3a6.noe.edf.fr:7687";
    private static final String USERNAME = "neo4j";
    private static final String PASSWORD = "password";
    private static final String DATABASE_NAME = "teggtestbrute";
    private static final String FILE_PATH = "/run/tmp_data/result_lines/data/886c63ea-b56f-4dbf-b2e6-10b65ca13e95";

    public static void main(String[] args) {
        // Charger les requêtes depuis le fichier
        List<String> queries = readQueriesFromFile(FILE_PATH);
         System.out.println("parameter");
        // Utilisation d'un pool d'threads pour exécuter les requêtes en parallèle
        int batchSize = 500; // Ajustez selon vos besoins
        ExecutorService executorService = Executors.newFixedThreadPool(10); // Nombre de threads

        List<List<String>> queryBatches = createQueryBatches(queries, batchSize);

        for (List<String> queryBatch : queryBatches) {
            executorService.submit(() -> executeTransaction(queryBatch));
        }

        executorService.shutdown();
        try {
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static List<String> readQueriesFromFile(String filePath) {
        List<String> queries = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                queries.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return queries;
    }

    private static List<List<String>> createQueryBatches(List<String> queries, int batchSize) {
        List<List<String>> queryBatches = new ArrayList<>();

        for (int i = 0; i < queries.size(); i += batchSize) {
            int endIndex = Math.min(i + batchSize, queries.size());
            queryBatches.add(new ArrayList<>(queries.subList(i, endIndex)));
        }

        return queryBatches;
    }

    private static void executeTransaction(List<String> queries) {
        try (Driver driver = GraphDatabase.driver(URI, AuthTokens.basic(USERNAME, PASSWORD));
             Session session = driver.session(SessionConfig.forDatabase(DATABASE_NAME))) {
            try (Transaction transaction = session.beginTransaction()) {
                for (String query : queries) {
                  System.out.println("hhhhh");
                    transaction.run(query);
                }
                transaction.commit();
            }
        }
    }
}
