import json
import sys
filename=sys.argv[2]
pathstore=sys.argv[1]


with open(pathstore+filename, 'r') as fichier_json:
    data = json.load(fichier_json)


lines = data.get('lines', [])

with open(pathstore+'result_lines/'+filename, 'w') as fichier_resultat:
    for line in lines:
        fichier_resultat.write(json.dumps(line))
        fichier_resultat.write('\n')

print("OK")
