# DHR-API-CLIENT
Base for ingesting HR datahub data 
