package com.apicil.rva.nifi.auth;

public class Auth {


    public static String gettoken(String input) {
        return input + "test";
    }

    public static void main(String[] args) {
        String texte = "bonjour ";
        String resultat = gettoken(texte);
        System.out.println(resultat);
    }
}
