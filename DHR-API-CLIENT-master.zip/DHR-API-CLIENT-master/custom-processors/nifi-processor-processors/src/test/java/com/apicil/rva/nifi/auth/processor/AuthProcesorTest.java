package com.apicil.rva.nifi.auth.processor;

import org.apache.nifi.util.MockFlowFile;
import org.apache.nifi.util.TestRunner;
import org.apache.nifi.util.TestRunners;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AuthProcesorTest {

    @Test
    void shouldRouteToSuccessAndWriteTokenInContent() {
        TestRunner runner = TestRunners.newTestRunner(AuthProcessor.class);
        runner.setProperty(AuthProcessor.PARAMS, "hello");
        runner.enqueue("input".getBytes(StandardCharsets.UTF_8));

        runner.run();

        runner.assertAllFlowFilesTransferred(AuthProcessor.SUCCESS, 1);
        runner.assertTransferCount(AuthProcessor.FAILURE, 0);

        List<MockFlowFile> out = runner.getFlowFilesForRelationship(AuthProcessor.SUCCESS);
        out.get(0).assertContentEquals("hellotest");
    }

    @Test
    void shouldEvaluateExpressionLanguageFromAttributes() {
        TestRunner runner = TestRunners.newTestRunner(AuthProcessor.class);
        runner.setProperty(AuthProcessor.PARAMS, "${myAttr}");

        Map<String, String> attributes = new HashMap<>();
        attributes.put("myAttr", "abc");

        runner.enqueue(
                "input".getBytes(StandardCharsets.UTF_8),
                attributes
        );

        runner.run();

        runner.assertAllFlowFilesTransferred(AuthProcessor.SUCCESS, 1);
        runner.assertTransferCount(AuthProcessor.FAILURE, 0);

        runner.getFlowFilesForRelationship(AuthProcessor.SUCCESS)
                .get(0)
                .assertContentEquals("abctest");
    }
}
