package com.apicil.rva.nifi.auth;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class AuthTest {
    @Test
    void shouldAddTestToInput() {
        // Given
        String input = "hello";

        // When
        String result = Auth.gettoken(input);

        // Then
        assertEquals("hellotest", result);
    }

    @Test
    void shouldWorkWithEmptyString() {
        // Given
        String input = "";

        // When
        String result = Auth.gettoken(input);

        // Then
        assertEquals("test", result);
    }
}
