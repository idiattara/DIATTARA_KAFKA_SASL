package com.tegg.datahub.neo4j.procedures.utils;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.internal.http.loader.DefaultSdkHttpClientBuilder;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.SdkHttpConfigurationOption;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3ClientBuilder;
import software.amazon.awssdk.services.s3.S3Configuration;
import software.amazon.awssdk.utils.AttributeMap;

import java.net.URI;

public class S3ClientUtils {
    public static S3Client getS3Client(String s3Accesskey, String s3Secretkey, String s3Url){
        final AttributeMap attributeMap = AttributeMap.builder()
                .put(SdkHttpConfigurationOption.TRUST_ALL_CERTIFICATES, true)
                .build();
        final SdkHttpClient sdkHttpClient = new DefaultSdkHttpClientBuilder().buildWithDefaults(attributeMap);

        Region region = Region.EU_WEST_1;
        S3ClientBuilder builder = S3Client.builder();
        builder.credentialsProvider(
                StaticCredentialsProvider.create(AwsBasicCredentials.create(s3Accesskey, s3Secretkey)));
        builder.endpointOverride(URI.create(s3Url));
        builder.region(region);
        S3Configuration confBuilder = S3Configuration.builder().pathStyleAccessEnabled(true).build();

        builder
                .serviceConfiguration(confBuilder)
                .httpClient(sdkHttpClient);


       return  builder.build();
    }

}
