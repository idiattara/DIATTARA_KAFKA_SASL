package com.tegg.datahub.neo4j.procedures.tegg;

import com.tegg.datahub.neo4j.procedures.records.RelationShipRecord;
import com.tegg.datahub.neo4j.procedures.utils.OntologyReader;
import com.tegg.datahub.neo4j.procedures.utils.TeggOntologyRelation;
import com.tegg.datahub.neo4j.procedures.EDFConfig.EDFConfig;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;
import org.neo4j.procedure.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

public class CreateRelationShips {
    @Context
    public Transaction tx;

    @Context
    public GraphDatabaseService db;

    @Context
    public Log log;

    @Context
    public TerminationGuard terminationGuard;

    @Procedure(value = "CreateRelationShips.createRelationShips", mode = Mode.WRITE)
    @Description("Create relationships between entities based on Ontologie")
    public Stream <RelationShipRecord> createRelationShips() {
        String paramfile="";
        String EDF_PARAM= EDFConfig.edfConfig().getEDF_Param();
        Path dir = Paths.get(EDF_PARAM+ File.separator+"param");
        if (Files.isDirectory(dir)) {
            Optional<Path> opPath;
            try {
                opPath = Files.list(dir)
                        .filter(p -> !Files.isDirectory(p) && p.getFileName().toString().contains("Ontology_2024-01-09.xlsx"))
                        .sorted((p1, p2)-> Long.valueOf(p2.toFile().lastModified())
                                .compareTo(p1.toFile().lastModified()))
                        .findFirst();

                if (opPath.isPresent()){
                    paramfile=opPath.get().toString();
                    System.out.println(paramfile);
                }

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


        }

        List<TeggOntologyRelation> relations = OntologyReader.read(paramfile);
        Map<String,  List<TeggOntologyRelation>> grouped = relations.stream().collect(groupingBy(TeggOntologyRelation::from,toList()));
        Stream<List<RelationShipRecord>> results =   grouped.keySet().stream().map(key->{
            StringBuilder whereClause = new StringBuilder("where");
            StringBuilder createRelation = new StringBuilder();
            StringBuilder stringBuilder  = new StringBuilder();
            stringBuilder.append("match(");
            stringBuilder.append(key + ":T_SRCOBJ_" + key + ")\n");

           grouped.get(key).stream().forEach(r->{
                stringBuilder.append(",(" + r.to + ":T_SRCOBJ_" + r.to + ") \n" );
                if ("BIBLIO".equals(r.from) && "REF_SITE".equals(r.to) ){
                    if (whereClause.toString().equals("where"))
                        whereClause.append(" " + r.from + ".nomDuSite=" + r.to + ".nomActivite\n");
                    else
                        whereClause.append(" and " +  r.from + ".nomDuSite=" + r.to + ".nomActivite\n");
                }
                if ("BIBLIO".equals(r.from) && "REF_PAYS".equals(r.to) ){
                    if (whereClause.toString().equals("where"))
                         whereClause.append(" " + r.from + ".paysSite=" + r.to + ".nom\n");
                    else
                        whereClause.append(" and " + r.from + ".paysSite=" + r.to + ".nom\n");
                }

                if ("BIBLIO".equals(r.from) && "REF_ENTREPRISE".equals(r.to) ){
                    if (whereClause.toString().equals("where"))
                        whereClause.append(" " + r.from + ".entreprise=" + r.to + ".nom\n");
                    else
                        whereClause.append(" and " + r.from + ".entreprise=" + r.to + ".nom\n");
                }

                if ("REFERENCES".equals(r.from) && "REF_SITE".equals(r.to) ){
                    if (whereClause.toString().equals("where"))
                        whereClause.append(" " + r.from + ".SITE=" + r.to + ".nomActivite\n");
                    else
                        whereClause.append(" and " + r.from + ".SITE=" + r.to + ".nomActivite\n");
                }

                if ("REFERENCES".equals(r.from) && "REF_PAYS".equals(r.to) ){
                    if (whereClause.toString().equals("where"))
                        whereClause.append(" " + r.from + ".PAYS=" + r.to + ".nom\n");
                    else
                        whereClause.append(" and " + r.from + ".PAYS=" + r.to + ".nom\n");
                }
                createRelation.append("CREATE " +  "(" + r.from+ ")-[" + r.name + ":RELTYPE{name: '" +r.name +"'}]->("+r.to + ")\n");

            });

            stringBuilder.append(whereClause);
            stringBuilder.append(createRelation);
            stringBuilder.append("return " +  relations.stream().map(r->r.name).collect(Collectors.joining(",")) );

            //return  stringBuilder.toString();
            try (Transaction tx = db.beginTx())
            {
                Result result = tx.execute(stringBuilder.toString());
                result.close();
               // return  Stream.empty();
                return  result.stream().map(row-> new RelationShipRecord((String) row.get("type"),(String) row.get("name"))).collect(Collectors.toList());
            }catch (Exception exception){
                throw exception;
            }
        });
        return Stream.empty();
    }


}
