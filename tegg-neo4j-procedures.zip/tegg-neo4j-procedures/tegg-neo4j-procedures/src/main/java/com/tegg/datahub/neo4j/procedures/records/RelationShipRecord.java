package com.tegg.datahub.neo4j.procedures.records;

public class RelationShipRecord {
    public final String type;
    public  final String name;
    public RelationShipRecord(String type, String name) {
        this.type = type;
        this.name = name;
    }

}

