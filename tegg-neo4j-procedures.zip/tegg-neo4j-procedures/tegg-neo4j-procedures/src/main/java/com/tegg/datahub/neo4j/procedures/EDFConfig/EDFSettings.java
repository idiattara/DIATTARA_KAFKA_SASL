package com.tegg.datahub.neo4j.procedures.EDFConfig;

import org.neo4j.annotations.service.ServiceProvider;
import org.neo4j.configuration.SettingValueParser;
import org.neo4j.configuration.SettingsDeclaration;
import org.neo4j.graphdb.config.Setting;


import static com.tegg.datahub.neo4j.procedures.EDFConfig.EDFConfig.*;
import static org.neo4j.configuration.SettingImpl.newBuilder;
import static org.neo4j.configuration.SettingValueParsers.STRING;


@ServiceProvider
public class EDFSettings implements SettingsDeclaration {

	public static final Setting<String> edf_config_path = newBuilder(EDF_CONFIG_PATH, STRING, null).build();
	public static final Setting<String> edf_config_tmp_path = newBuilder(EDF_CONFIG_TMP_PATH, STRING, null).build();

	public static final Setting<String> edf_s3_server = newBuilder(EDF_S3_SERVER, STRING, null).build();
	public static final Setting<String> edf_s3_accesskey = newBuilder(TEGG_S3_ACCESSKEY, STRING, null).build();
	public static final Setting<String> edf_s3_secretkey = newBuilder(TEGG_S3_SECRETKEY, STRING, null).build();
	public static final Setting<String> edf_s3_bucket = newBuilder(TEGG_S3_BUCKET, STRING, null).build();
	public static final Setting<String> edf_s3_remotepath = newBuilder(TEGG_S3_REMOTEPATH, STRING, null).build();

    public static <T> Setting<T> dynamic(String name, SettingValueParser<T> parser) {
        return newBuilder(name, parser, null).build();
    }
}