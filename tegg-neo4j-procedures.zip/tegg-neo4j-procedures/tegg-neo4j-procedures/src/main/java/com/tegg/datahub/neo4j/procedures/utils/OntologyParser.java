package com.tegg.datahub.neo4j.procedures.utils;

import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class OntologyParser {


    public static  List<TeggOntologyRelation> read(String ontology ){
        List<TeggOntologyRelation> relations = new ArrayList<>();
        try (InputStream is = new FileInputStream(ontology); Workbook wb = new XSSFWorkbook(is)) {
            FormulaEvaluator  evaluator = wb.getCreationHelper().createFormulaEvaluator();

            if (wb.getSheetIndex("REFERENCES")>-1) {
                Sheet biblio = wb.getSheet("REFERENCES");
                final AtomicInteger nbRows = new AtomicInteger(0);
                final AtomicInteger nbCols = new AtomicInteger(0);
                final AtomicInteger colClass= new AtomicInteger(-1);
                final AtomicInteger colName= new AtomicInteger(-1);
                final AtomicInteger colActive= new AtomicInteger(-1);
                final AtomicInteger colType= new AtomicInteger(-1);
                final AtomicInteger colUnit= new AtomicInteger(-1);
                final AtomicInteger colPrecision= new AtomicInteger(-1);
                final AtomicInteger colIsId= new AtomicInteger(-1);
                final AtomicInteger colIsMandatory= new AtomicInteger(-1);
                final AtomicInteger colComposite= new AtomicInteger(-1);
                final AtomicInteger colChecks= new AtomicInteger(-1);
                final AtomicInteger colCompute= new AtomicInteger(-1);
                final AtomicInteger colMultiple= new AtomicInteger(-1);
                final AtomicInteger colAuto= new AtomicInteger(-1);
                final AtomicInteger colIgnore= new AtomicInteger(-1);
                final AtomicInteger colDefaut= new AtomicInteger(-1);
                final AtomicInteger colDescription= new AtomicInteger(-1);
                final AtomicInteger colFrom= new AtomicInteger(-1);
                final AtomicInteger colTo= new AtomicInteger(-1);

                biblio.forEach(r -> {
                    if(nbRows.get()==0)
                    {
                        r.forEach( c -> {
                            String colname = Utils.getCellData(c, evaluator).trim();
                            if(colname.equals("class"))
                            {
                                colClass.set(nbCols.intValue());
                            }
                            else if(colname.equals("name"))
                            {
                                colName.set(nbCols.intValue());
                            }
                            else if(colname.equals("active"))
                            {
                                colActive.set(nbCols.intValue());
                            }
                            else if(colname.equals("type"))
                            {
                                colType.set(nbCols.intValue());
                            }
                            else if(colname.equals("unit"))
                            {
                                colUnit.set(nbCols.intValue());
                            }
                            else if(colname.equals("precision"))
                            {
                                colPrecision.set(nbCols.intValue());
                            }
                            else if(colname.equals("isId"))
                            {
                                colIsId.set(nbCols.intValue());
                            }
                            else if(colname.equals("isMandatory"))
                            {
                                colIsMandatory.set(nbCols.intValue());
                            }
                            else if(colname.equals("composite"))
                            {
                                colComposite.set(nbCols.intValue());
                            }

                            else if(colname.equals("checks"))
                            {
                                colChecks.set(nbCols.intValue());
                            }
                            else if(colname.equals("compute"))
                            {
                                colCompute.set(nbCols.intValue());
                            }
                            else if(colname.equals("multiple"))
                            {
                                colMultiple.set(nbCols.intValue());
                            }
                            else if(colname.equals("auto"))
                            {
                                colAuto.set(nbCols.intValue());
                            }
                            else if(colname.equals("ignore"))
                            {
                                colIgnore.set(nbCols.intValue());
                            }
                            else if(colname.equals("defaut"))
                            {
                                colDefaut.set(nbCols.intValue());
                            }
                            else if(colname.equals("from"))
                            {
                                colFrom.set(nbCols.intValue());
                            }
                            else if(colname.equals("to"))
                            {
                                colTo.set(nbCols.intValue());
                            }

                            nbCols.incrementAndGet();
                        });

                    } else {

                        String classValue="";
                        if(colClass.intValue()>-1)
                            classValue=Utils.getCellData(r.getCell(colClass.intValue()),evaluator).trim();
                        if ( "Rel".equals(classValue)){
                            TeggOntologyRelation teggOntologyRelation = new TeggOntologyRelation();
                            if(colName.intValue()>-1)
                                teggOntologyRelation.name  = Utils.getCellData(r.getCell(colName.intValue()),evaluator).trim();
                            if(colFrom.intValue()>-1)
                                teggOntologyRelation.from = Utils.getCellData(r.getCell(colFrom.intValue()),evaluator).trim();
                            if(colTo.intValue()>-1)
                                teggOntologyRelation.to = Utils.getCellData(r.getCell(colTo.intValue()),evaluator).trim();
                            relations.add(teggOntologyRelation);
                        }
                    }
                    nbRows.incrementAndGet();
                });
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        return relations;
    }
}

