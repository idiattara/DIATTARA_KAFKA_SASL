package com.tegg.datahub.neo4j.procedures.EDFConfig;
import apoc.RegisterComponentFactory;
import org.neo4j.annotations.service.ServiceProvider;
import org.neo4j.dbms.api.DatabaseManagementService;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.internal.kernel.api.Procedures;
import org.neo4j.kernel.api.procedure.GlobalProcedures;
import org.neo4j.kernel.availability.AvailabilityGuard;
import org.neo4j.kernel.availability.AvailabilityListener;
import org.neo4j.kernel.extension.ExtensionFactory;
import org.neo4j.kernel.extension.ExtensionType;
import org.neo4j.kernel.extension.context.ExtensionContext;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.kernel.lifecycle.Lifecycle;
import org.neo4j.kernel.lifecycle.LifecycleAdapter;
import org.neo4j.logging.Log;
import org.neo4j.logging.internal.LogService;
import org.neo4j.scheduler.JobScheduler;
import org.neo4j.service.Services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import static org.neo4j.configuration.GraphDatabaseSettings.SYSTEM_DATABASE_NAME;

/**
 * @author mh
 * @since 14.05.16
 */
@ServiceProvider
public class EDFExtensionFactory extends ExtensionFactory<EDFExtensionFactory.Dependencies> {

    
    public EDFExtensionFactory() {
        super(ExtensionType.DATABASE, "EDF");
    }

    public interface Dependencies {
        GraphDatabaseAPI graphdatabaseAPI();
        JobScheduler scheduler();
        Procedures procedures();
        LogService log();
        AvailabilityGuard availabilityGuard();
        DatabaseManagementService databaseManagementService();
        EDFConfig edfConfig();
        GlobalProcedures globalProceduresRegistry();
        //ExtendedRegisterComponentFactory.RegisterComponentLifecycle registerComponentLifecycle();
        RegisterComponentFactory.RegisterComponentLifecycle registerComponentLifecycle();
    }

    @Override
    public Lifecycle newInstance(ExtensionContext context, Dependencies dependencies) {
    	GraphDatabaseAPI db = dependencies.graphdatabaseAPI();
        LogService log = dependencies.log();
        return new EDFLifecycle(log, db, dependencies);
    }

    public static class EDFLifecycle extends LifecycleAdapter {

        
        private final Log userLog;
        private final GraphDatabaseAPI db;
        private final Dependencies dependencies;
        private final Map<String, Lifecycle> services = new HashMap<>();

        // maps a component class to database name to resolver

        private final Collection<EDFGlobalComponents> edfGlobalComponents;
        private final Collection<AvailabilityListener> registeredListeners = new ArrayList<>();

        public EDFLifecycle(LogService log, GraphDatabaseAPI db, Dependencies dependencies) {

            this.db = db;
            this.dependencies = dependencies;
            this.userLog = log.getUserLog(EDFExtensionFactory.class);
            this.edfGlobalComponents = Services.loadAll(EDFGlobalComponents.class);
        }

        public static void withNonSystemDatabase(GraphDatabaseService db, Consumer<Void> consumer) {
            if (!SYSTEM_DATABASE_NAME.equals(db.databaseName())) {
                consumer.accept(null);
            }
        }

        @Override
        public void init() throws Exception {
        	withNonSystemDatabase(db, aVoid -> {

                for (EDFGlobalComponents c: edfGlobalComponents) {
                    services.putAll(c.getServices(db, dependencies));
                }

                String databaseName = db.databaseName();
                services.values().forEach(lifecycle -> dependencies.registerComponentLifecycle().addResolver(
                        databaseName,
                        lifecycle.getClass(),
                        lifecycle));

            });
        }

        @Override
        public void start() {
        	withNonSystemDatabase(db, aVoid -> {
                services.forEach((key, value) -> {
                    try {
                        value.start();
                    } catch (Exception e) {
                        userLog.error("failed to start service " + key, e);
                    }
                });

            });

            AvailabilityGuard availabilityGuard = dependencies.availabilityGuard();
            for (EDFGlobalComponents c: edfGlobalComponents) {
                for (AvailabilityListener listener: c.getListeners(db, dependencies)) {
                	registeredListeners.add( listener );
                	availabilityGuard.addListener(listener);
                }
            }
        }

        @Override
        public void stop() {
            withNonSystemDatabase(db, aVoid -> {
                services.forEach((key, value) -> {
                    try {
                        value.stop();
                    } catch (Exception e) {
                        userLog.error("failed to stop service " + key, e);
                    }
                });
            });
        }
        
        public Collection<AvailabilityListener> getRegisteredListeners()
        {
            return registeredListeners;
        }
        
    }
}