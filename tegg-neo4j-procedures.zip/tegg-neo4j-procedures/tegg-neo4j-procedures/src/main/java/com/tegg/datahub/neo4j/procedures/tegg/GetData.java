package com.tegg.datahub.neo4j.procedures.tegg;

import apoc.ApocConfig;
import apoc.Pools;
import apoc.export.json.ExportJson;
import apoc.result.ProgressInfo;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;
import org.neo4j.procedure.*;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static com.tegg.datahub.neo4j.procedures.EDFConfig.EDFConfig.edfConfig;
public class GetData {

    @Context
    public Transaction tx;

    @Context
    public GraphDatabaseService db;

    @Context
    public Log log;
    @Context
    public ApocConfig apocConfig;

    @Context
    public TerminationGuard terminationGuard;
    @Context
    public Pools pools;


    @Procedure(value = "GetData.getData", mode = Mode.READ)
    @Description("Get data from teggstagging")
    public Stream<ProgressInfo> getData(
            @Name("params") Map<String, Object> params
    ) {

        final String  EDF_CONFIG_TMP_PATH= edfConfig().getString("edf.config.tmp.path");
        String campagne = (String) params.get("CAMPAGNE");
        String object = (String) params.get("SRC_OBJECT_NAME");
        String user = (String) params.get("USER_NAME");
        String site = (String) params.get("SITE");
        String date=(String) params.get("INTEGRATION_DATE");
        final SimpleDateFormat formater = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        final String filename = EDF_CONFIG_TMP_PATH + object+ "_" + formater.format(new Date())  + ".json";
        StringBuilder cypher = new StringBuilder();
        String requete1 = "MATCH (p:`" + "T_CAMP_" + campagne + "`" + ":`T_SRCOBJ_" + object + "`" + ":`T_USER_" + user +  "`:`T_DATE_" + date +  "`) where p.SITE ='" + site +"'";
        //String requete2 = "MATCH (p:`" + "T_CAMP_" + campagne + "`" + ":`T_SRCOBJ_" + object + "`" + ":`T_USER_" + user +  "`)";
        String requete2 = "MATCH (p:`T_CAMP_" + campagne + "`:`T_SRCOBJ_" + object + "`:`T_USER_" + user + "`:`T_DATE_" + date + "`)";

        cypher.append(requete1  + "\n");
        cypher.append("OPTIONAL \n"  );
        cypher.append(requete2 + "-[r]->(m)   RETURN p, r, m"  );
        try (Transaction tx = db.beginTx())
        {
            ExportJson exportJson = new ExportJson();
            exportJson.apocConfig = this.apocConfig;
            exportJson.db = this.db;
            exportJson.terminationGuard = this.terminationGuard;
            exportJson.pools = this.pools;
            Result result = tx.execute(cypher.toString());
            List<Node> nodes = result.stream().map(r->{
                Node node=(Node) r.get("p");
                return  node;
            }).collect(Collectors.toList());
            Stream<ProgressInfo>   progressInfoStream = exportJson.data(nodes, Collections.EMPTY_LIST,   filename, null);
            if (result != null) result.close();
            return progressInfoStream;

        }catch (Exception e){
            e.printStackTrace();
        }
        return Stream.empty();

    }

}
