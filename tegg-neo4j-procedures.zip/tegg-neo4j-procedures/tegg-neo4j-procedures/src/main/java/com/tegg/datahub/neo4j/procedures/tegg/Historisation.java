package com.tegg.datahub.neo4j.procedures.tegg;

import apoc.ApocConfig;
import apoc.Pools;
import apoc.export.json.ExportJson;
import apoc.result.NodeResult;
import apoc.result.ProgressInfo;
import apoc.result.VirtualNode;
import apoc.util.Util;
import org.neo4j.graphdb.*;
import org.neo4j.procedure.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.tegg.datahub.neo4j.procedures.EDFConfig.EDFConfig.edfConfig;

public class Historisation {


    @Context
    public GraphDatabaseService db;

    @Context
    public ApocConfig apocConfig;

    @Context
    public TerminationGuard terminationGuard;
    @Context
    public Pools pools;
    final static Instant instant = Instant.now();
    final static SimpleDateFormat formater = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    //final static String timestamp = formater.format(new Date());


    private static Map<String,Object> jsonExportConfig;
    static {
        jsonExportConfig = new HashMap<>();
        jsonExportConfig.put("jsonFormat", "ARRAY_JSON");

    }
    @Procedure(value = "stagging.getData", mode = Mode.READ)
    @Description("Historisation Get data from teggstagging")
    public Stream<ProgressInfo>  getDataFromStaging(
            @Name("params") Map<String, Object> params
    ) {
        final String  EDF_CONFIG_TMP_PATH= edfConfig().getString("edf.config.tmp.path");
        String campagne = (String) params.get("CAMPAGNE");
        String object = (String) params.get("SRC_OBJECT_NAME");
        String user = (String) params.get("USER_NAME");

        String requete = "MATCH (p:`" + "T_CAMP_" + campagne + "`" + ":`T_SRCOBJ_" + object + "`" + ":`T_USER_" + user +  "`) return p";
        String filename = EDF_CONFIG_TMP_PATH  +"stagging_" + object +"_" + campagne +"_"+ user +"_"+ instant.getEpochSecond()+ ".json";
        try (Transaction tx = db.beginTx())
        {
            ExportJson exportJson = new ExportJson();
            exportJson.apocConfig = this.apocConfig;
            exportJson.db = this.db;
            exportJson.terminationGuard = this.terminationGuard;
            exportJson.pools = this.pools;
            exportJson.tx = tx;
            Result result = tx.execute(requete);
            List<NodeResult> nodes = filterFields(result, "stagging", object , user, campagne);
            tx.commit();
            Stream<ProgressInfo>   progressInfoStream = exportJson.data(nodes.stream().map(r->r.node).collect(Collectors.toList()), Collections.EMPTY_LIST,   filename, jsonExportConfig);
            if (result != null) result.close();
            return progressInfoStream;
        }catch (Exception e){
            e.printStackTrace();
        }
        return Stream.empty();
    }

    @Procedure(value = "tegg.getData", mode = Mode.READ)
    @Description("Historisation Get data from tegg")
    public Stream<ProgressInfo>  getDataFromTegg(
            @Name("file1") String file,
            @Name("params") Map<String, Object> params
    ) {
        final String  EDF_CONFIG_TMP_PATH= edfConfig().getString("edf.config.tmp.path");
        String object = (String) params.get("SRC_OBJECT_NAME");
        String ged = (String) params.get("GED");

        String filename = EDF_CONFIG_TMP_PATH + "tegg_" + object +"_" +ged  +"_"+ instant.getEpochSecond()+ ".json";
        String requete = "CALL apoc.load.json('" + file +  "') yield value  with collect(value.properties.TECHNICAL_ID) as  ids MATCH (p:`T_SRCOBJ_" + object + "`" + ":`T_GED_" + ged+  "`) where p.TECHNICAL_ID in  ids return p";
        try (Transaction tx = db.beginTx())
        {
            ExportJson exportJson = new ExportJson();
            exportJson.apocConfig = this.apocConfig;
            exportJson.db = this.db;
            exportJson.terminationGuard = this.terminationGuard;
            exportJson.pools = this.pools;
            exportJson.tx = tx;
            Result result = tx.execute(requete);
            List<NodeResult> nodes = filterFields(result, "tegg", null, null, null);
            tx.commit();

            Stream<ProgressInfo>   progressInfoStream = exportJson.data(nodes.stream().map(r->r.node).collect(Collectors.toList()), Collections.EMPTY_LIST,   filename, jsonExportConfig);
            if (result != null) result.close();
            return progressInfoStream;

        }catch (Exception e){
            e.printStackTrace();
        }
        return Stream.empty();
    }


    @UserFunction(value = "histo.compare")
    @Description("Historisation compare")
    public String  compare(
            @Name("file1") String file1, @Name("file2") String file2
    ) {

        String requete1 = "call apoc.load.json('" + file1 + "') yield value  return value.properties as result1";
        String requete2 = "call apoc.load.json('" + file2 + "') yield value  return value.properties as result2";
        try (Transaction tx = db.beginTx())
        {
            final  String timestamp = formater.format(new Date());
            ExportJson exportJson = new ExportJson();
            exportJson.apocConfig = this.apocConfig;
            exportJson.db = this.db;
            exportJson.terminationGuard = this.terminationGuard;
            exportJson.pools = this.pools;
            exportJson.tx = tx;
            Result result1 = tx.execute(requete1);
            List<HashMap<String,Object>> resultFromTegg= result1.stream().map(record->{

                HashMap<String,Object>  map = (HashMap<String, Object>) record.get("result1");
                return map;
            }).collect(Collectors.toList());
            Result result2 = tx.execute(requete2);
            List<HashMap<String,Object>> resultFromStaging= result2.stream().map(record->{

                HashMap<String,Object>  map = (HashMap<String, Object>) record.get("result2");
                return map;
            }).collect(Collectors.toList());
            StringBuilder user = new StringBuilder();
            StringBuilder ged =  new StringBuilder();
            StringBuilder objectName = new StringBuilder();
            StringBuilder projet = new StringBuilder();
            StringBuilder site = new StringBuilder();


            StringBuilder linesStringBuilder = new StringBuilder();
            linesStringBuilder.append("'lines':[");
            resultFromTegg.stream().forEach(elt->{
                HashMap<String,Object> toCompare=  resultFromStaging.stream().filter(elt2->(elt.get("TECHNICAL_ID")).equals(elt2.get("TECHNICAL_ID"))).collect(Collectors.toList()).get(0);
                elt.keySet().stream().forEach(key->{
                    if (!"user".equals(key)
                            && !"objet".equals(key)
                            && !"campagne".equals(key)
                            && !"SITE".equalsIgnoreCase(key)
                            && !elt.get(key).equals(toCompare.get(key)) ){
                        if (projet.toString().isEmpty())
                            projet.append(toCompare.get("PROJET"));
                        if (site.toString().isEmpty())
                            site.append(toCompare.get("SITE"));
                        if (user.toString().isEmpty())
                            user.append(toCompare.get("user"));
                        if (ged.toString().isEmpty())
                            ged.append(toCompare.get("campagne"));
                        if (objectName.toString().isEmpty())
                            objectName.append(toCompare.get("objet"));
                        if (! "'lines':[".equals(linesStringBuilder.toString()))
                            linesStringBuilder.append(",");
                        linesStringBuilder.append("{'field' :" + "'"  +  key + "'," + "'oldvalue':'" + elt.get(key) + "',"+ "'newvalue':'" + toCompare.get(key)  + "'," + "'TECHNICAL_ID':'" + elt.get("TECHNICAL_ID") +  "'}");
                    }
                });
            });
            if (!"'lines':[".equals(linesStringBuilder.toString())){
                linesStringBuilder.append("]");
                String log = timestamp.replaceAll(":", "_");
                log = log.replaceAll("-", "_");
                log = log.replaceAll(" ", "_");
                StringBuilder cypher =  new StringBuilder("MERGE (obj:`T_SRCOBJ_"+ objectName + "`:`T_GED_" +ged +  "`:`T_PROJECT_" + projet + "`:`T_SITE_"+ site + "`) SET obj.log_" + log + "=\"");
                cypher.append("{'timestamp': '" + timestamp+ "'," + "'user':'" + user +  "',");
                cypher.append(linesStringBuilder);
                cypher.append("}\"");
                if (result1 != null) result2.close();
                if (result2 != null) result2.close();
                return cypher.toString();
            }
        }catch (Exception e){
            e.printStackTrace();
            return "KO";
        }
        return  "OK";
    }

    @Procedure(value = "histo.update", mode = Mode.WRITE)
    @Description("Historisation update data change")
    public Stream<LogUpdateResult>  updateLog(
            @Name("file1") String file1, @Name("file2") String file2
    ) {
        String result = compare(file1,file2);
        if ("OK".equalsIgnoreCase(result)){
            try {
                Files.delete(Paths.get(new URI(file1)));
                Files.delete(Paths.get(new URI(file2)));
            } catch (URISyntaxException | IOException e) {
                e.printStackTrace();
            }
            return Stream.of(new LogUpdateResult("OK"));
        }

        if ("KO".equalsIgnoreCase(result)){

            try {
                Files.delete(Paths.get(new URI(file1)));
                Files.delete(Paths.get(new URI(file2)));
            } catch (URISyntaxException | IOException e) {
                e.printStackTrace();
            }
            return Stream.of(new LogUpdateResult("KO"));
        }


        try (Transaction tx = db.beginTx())
        {

            Result res = tx.execute(result);
            tx.commit();
            res.close();
            try {
                Files.delete(Paths.get(new URI(file1)));
                Files.delete(Paths.get(new URI(file2)));
            } catch (URISyntaxException | IOException e) {
                e.printStackTrace();
            }
            return Stream.of(new LogUpdateResult("OK"));
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            Files.delete(Paths.get(new URI(file1)));
            Files.delete(Paths.get(new URI(file2)));
        } catch (URISyntaxException | IOException e) {
            e.printStackTrace();
        }
        return Stream.of(new LogUpdateResult("KO"));
    }
    private   List<NodeResult> filterFields( Result result, String label, String objet, String user, String campagne){
        return result.stream()
                .map(record ->{
                    Node node = (Node) record.get("p");
                    Map<String,Object>  properties = node.getAllProperties();
                    Map<String,Object>  copy = new HashMap<>(properties);
                    copy.keySet().stream().filter(key->key.endsWith("_calc") ||
                            key.equals("FILENAME") ||
                            key.equals("GED") ||
                            key.equals("S3PATH") ||
                            //  key.equals("SITE") ||
                            key.equals("ENTREPRISE") ||
                            key.equals("LIEN_GED") ||
                            key.equals("COMMENTAIRE") ||
                            key.equals("INDICATEUR_QUALITATIF") ||
                            key.equals("PAYS") ||
                            key.equals("TYPE_ACTIVITE") ||
                            key.equals("TYPE_OUVRAGE") ||
                            key.equals("TYPE_RAPPORT") ||
                            key.equals("DATE") ||
                            key.equals("PARENT_ENFANT") ||
                            key.equals("GED_PARENT") ||
                            key.equals("GED_ENFANT") ||
                            key.equals("MODE")).collect(Collectors.toList()).forEach(properties.keySet()::remove);
                    List<String> labelnames=new ArrayList<String>();
                    labelnames.add(label);
                    Label labs[]= Util.labels(labelnames);
                    if (objet != null && user !=  null && campagne != null){
                        properties.put("objet", objet);
                        properties.put("user", user);
                        properties.put("campagne", campagne);
                    }

                    VirtualNode vn=new VirtualNode(labs,properties) ;
                    return new NodeResult(vn);
                })
                .collect(Collectors.toList());
    }


    public class LogUpdateResult {
        public final String response;

        public LogUpdateResult(String response) {
            this.response = response;

        }
    }
}
