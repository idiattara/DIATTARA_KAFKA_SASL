package com.tegg.datahub.neo4j.procedures.EDFConfig;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.ex.ConversionException;
import org.neo4j.configuration.Config;
import org.neo4j.dbms.api.DatabaseManagementService;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.kernel.api.procedure.GlobalProcedures;
import org.neo4j.kernel.lifecycle.LifecycleAdapter;
import org.neo4j.logging.Log;
import org.neo4j.logging.NullLog;
import org.neo4j.logging.internal.LogService;

import java.io.File;
import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;

import static org.neo4j.configuration.GraphDatabaseSettings.SYSTEM_DATABASE_NAME;

public class EDFConfig extends LifecycleAdapter {

    public static final String SUN_JAVA_COMMAND = "sun.java.command";
    public static final String EDF_CONFIG_PATH = "edf.config.path";
    public static final String EDF_CONFIG_TMP_PATH = "edf.config.tmp.path";

    public static final String EDF_S3_SERVER = "edf.config.s3.server";
    public static final String TEGG_S3_ACCESSKEY = "tegg.config.s3.accesskey";
    public static final String TEGG_S3_SECRETKEY = "tegg.config.s3.secretkey";
    public static final String TEGG_S3_BUCKET = "tegg.config.s3.bucket";
    public static final String TEGG_S3_REMOTEPATH = "tegg.config.s3.remotepath";



    private final Config neo4jConfig;
    private final Log log;
    private final DatabaseManagementService databaseManagementService;

    private Configuration config;

    private static EDFConfig theInstance;
    private LoggingType loggingType;



    private GraphDatabaseService systemDb;

    String EDF_Param;
    HashMap<String,String> PDMSPeres;

    /**
     * keep track if this instance is already initialized so dependent class can wait if needed
     */
    private boolean initialized = false;


    /*public EDFConfig(LogService log, GlobalProcedures globalProceduresRegistry) {
        this.log = log.getInternalLog(EDFConfig.class);
        theInstance = this;
        this.neo4jConfig = null;
        // expose this config instance via `@Context ApocConfig config`
        globalProceduresRegistry.registerComponent((Class<EDFConfig>) getClass(), ctx -> this, true);
        this.log.info("successfully registered ExtendedApocConfig for @Context");
    }*/

    public EDFConfig(Config neo4jConfig, LogService log, GlobalProcedures globalProceduresRegistry, DatabaseManagementService databaseManagementService) {

        this.neo4jConfig = neo4jConfig;

        this.log = log.getInternalLog(EDFConfig.class);
        this.databaseManagementService = databaseManagementService;
        theInstance = this;
        this.config = new PropertiesConfiguration();
        // expose this config instance via `@Context EDFConfig config`
        globalProceduresRegistry.registerComponent((Class<EDFConfig>) getClass(), ctx -> this, true);
        this.log.info("successfully registered EDFConfig for @Context");

    }

    // use only for unit tests
    public EDFConfig() {
        this.neo4jConfig = null;
        this.log = NullLog.getInstance();
        this.databaseManagementService = null;
        theInstance = this;
        this.PDMSPeres=new HashMap<String,String>();
        this.config = new PropertiesConfiguration();
        this.EDF_Param="/appli/neo4j";
    }

    public Configuration getConfig() {
        return config;
    }

    @Override
    public void init() throws Exception {
        log.debug("called init EDFConfig");

        loadConfiguration();
        initialized = true;
    }





    public boolean isInitialized() {
        return initialized;
    }




    protected void loadConfiguration() {
        try {

            // copy apoc settings from neo4j.conf for legacy support
            neo4jConfig.getDeclaredSettings().entrySet().stream()
                    .filter(e -> !config.containsKey(e.getKey()))
                    .filter(e -> e.getKey().startsWith("edf.") || e.getKey().startsWith("tegg."))
                    .forEach(e -> {
                        log.info("setting from neo4j.conf: " + e.getKey() + "=" + neo4jConfig.get(e.getValue()));
                        config.setProperty(e.getKey(), neo4jConfig.get(e.getValue()));
                    });

            EDF_Param=config.getString(EDF_CONFIG_PATH);


            PDMSPeres=new HashMap<String,String>();

            String paramfile=EDF_Param+File.separator+"param"+File.separator+"mapping_Parents.xlsx";
           /* if(EDF_Param!=null)
            {
                //=============================================Parse Excel sheets=======================================================================
                try (InputStream is = new FileInputStream(paramfile); ReadableWorkbook  wb = new ReadableWorkbook(is)) {

                    Sheet sheet = wb.findSheet("CM_HPC_param_3D").get();

                    final AtomicInteger nbrows2 = new AtomicInteger(0);
                    try (Stream<Row> rows = sheet.openStream()) {
                        rows.forEach(r -> {
                            if(nbrows2.get()>0)
                            {
                                PDMSPeres.put( r.getCellAsString(0).orElse("").trim(), r.getCellAsString(2).orElse("").trim());

                            }
                            nbrows2.incrementAndGet();
                        });
                    }

                    if(wb!=null)
                        wb.close();
                    if(is!=null)
                        is.close();

                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }*/


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



    public LoggingType getLoggingType() {
        return loggingType;
    }


    public void setLoggingType(LoggingType loggingType) {
        this.loggingType = loggingType;
    }


    public GraphDatabaseService getSystemDb() {
        if (systemDb == null) {
            try {
                systemDb = databaseManagementService.database(SYSTEM_DATABASE_NAME);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return systemDb;
    }

    public GraphDatabaseService getDb(String dbname) {
        GraphDatabaseService db;
        try {
            db = databaseManagementService.database(dbname);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return db;
    }

    public enum LoggingType {none, safe, raw}

    private void initLogging() {
        loggingType = LoggingType.valueOf(config.getString("edf.user.log.type", "safe").trim());

    }

    public static EDFConfig edfConfig() {
        return theInstance;
    }


    /*
     * delegate methods for Configuration
     */

    public Iterator<String> getKeys(String prefix) {
        return getConfig().getKeys(prefix);
    }

    public boolean containsKey(String key) {
        return getConfig().containsKey(key);
    }

    public String getString(String key) {
        return getConfig().getString(key);
    }

    public String getString(String key, String defaultValue) {
        return getConfig().getString(key, defaultValue);
    }

    public void setProperty(String key, Object value) {
        getConfig().setProperty(key, value);
    }

    public boolean getBoolean(String key) {
        return getConfig().getBoolean(key);
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        return getConfig().getBoolean(key, defaultValue);
    }


    public int getInt(String key, int defaultValue) {
        try {
            return getConfig().getInt(key, defaultValue);
        } catch (ConversionException e) {
            Object o = getConfig().getProperty(key);
            if (o instanceof Duration) {
                return (int) ((Duration)o).getSeconds();
            } else {
                throw new IllegalArgumentException("don't know how to convert for config option " + key, e);
            }
        }
    }

    public HashMap<String,String> getPDMSPeres() {
        return PDMSPeres;
    }

    public String getEDF_Param() {
        return EDF_Param;
    }

}