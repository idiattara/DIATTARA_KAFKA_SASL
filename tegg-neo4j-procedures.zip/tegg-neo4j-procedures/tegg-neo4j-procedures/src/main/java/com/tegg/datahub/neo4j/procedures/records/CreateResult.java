package com.tegg.datahub.neo4j.procedures.records;

public class CreateResult {
    public final String result;
    public CreateResult(String result) {
        this.result = result;
    }
}
