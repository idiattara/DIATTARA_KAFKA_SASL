package com.tegg.datahub.neo4j.procedures.utils;

import com.sun.istack.Nullable;
import org.apache.poi.ss.format.CellDateFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;

import java.util.Date;
import java.util.regex.Pattern;

public class Utils {
	static Pattern escPattern = Pattern.compile("(-|[0-9])([A-Z]{3})([0-9]{3})([0-9])([A-Z]{2})(-|[0-9]|[A-Z])");
	
	public static boolean checkECS(String s) {
		return escPattern.matcher(s).matches();
	}

	public static String getCellData(@Nullable Cell myCell,FormulaEvaluator evaluator) {
	    if (myCell == null) return "";
	    String cellDataStr="";
	    try
	    {
		    switch (myCell.getCellType()) {
		      case FORMULA:
		    	  evaluator.evaluateInCell(myCell);
		    	  cellDataStr = getCellData(myCell);
		        break;
		      default:
		        cellDataStr = getCellData(myCell);
		    }
	    }
	    catch(Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    return cellDataStr;
	  }
	
	
	public static String getCellData(@Nullable Cell myCell) {
	    if (myCell == null) return "";
	    final String cellDataStr;

	    switch (myCell.getCellType()) {
	      case STRING:
	        cellDataStr = myCell.getRichStringCellValue().getString();
	        break;
	      case BOOLEAN:
	        cellDataStr = Boolean.toString(myCell.getBooleanCellValue());
	        break;
	      case NUMERIC:

	    	 if (DateUtil.isCellDateFormatted(myCell)) {
	    		 //CellStyle style = myCell.getCellStyle();
	    		 Date myDate= myCell.getDateCellValue();
                 //String format = style.getDataFormatString();
	    		 String format = "dd/mm/yyyy";
	    		 cellDataStr= new CellDateFormatter(format).format(myDate);
	            } else {
	            	myCell.setCellType(CellType.STRING); ; 	
	            	String stmp = myCell.getRichStringCellValue().getString();

	            	if(stmp==null || stmp.length()==0)
	            		cellDataStr="";
	            	else if(stmp.endsWith(".0"))
	            		cellDataStr = stmp.substring(0, stmp.length()-2);
	            	else
	            		cellDataStr=stmp;
	            	
	            	//cellDataStr=Double.toString(myCell.getNumericCellValue());
	            }
	        break;
	      case ERROR:
	        cellDataStr = "ERROR";
	        break;
	      case BLANK:
	        cellDataStr = "";
	        break;
	      default:
	        cellDataStr = "";
	    }
	    return cellDataStr;
	  }
}
