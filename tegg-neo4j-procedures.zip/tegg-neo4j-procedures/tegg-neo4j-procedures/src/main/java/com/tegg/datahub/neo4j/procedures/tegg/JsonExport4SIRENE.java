package com.tegg.datahub.neo4j.procedures.tegg;

import apoc.ApocConfig;
import apoc.Pools;
import apoc.export.json.ExportJson;
import apoc.result.ProgressInfo;
import com.tegg.datahub.neo4j.procedures.utils.ExportToS3;
import com.tegg.datahub.neo4j.procedures.utils.S3ClientUtils;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;
import org.neo4j.procedure.*;
import software.amazon.awssdk.services.s3.S3Client;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.tegg.datahub.neo4j.procedures.EDFConfig.EDFConfig.edfConfig;

public class JsonExport4SIRENE {

    @Context
    public Transaction tx;

    @Context
    public GraphDatabaseService db;

    @Context
    public Log log;

    @Context
    public ApocConfig apocConfig;

    @Context
    public TerminationGuard terminationGuard;

    @Context
    public Pools pools;

    //static final String sirene ="MATCH (p:T_SRCOBJ_SIRENE) RETURN p.date AS date, p.SITE AS SITE, p.DATE_FORMAT_date AS DATE_FORMAT_date, p.sources AS sources, p.valeur AS valeur, p.unite AS unite, p.nom_piezo AS nom_piezo, p.substance AS substance, p.TECHNICAL_ID AS TECHNICAL_ID, p.GED_PARENT AS GED_PARENT, p.site AS site, p.valeurCensure AS valeurCensure, p.id AS id, p.commentaire AS commentaire, p.FILENAME AS FILENAME, p.substance_renomme_sirene AS substance_renomme_sirene";
      static final String sirene = "MATCH (p:T_SRCOBJ_SIRENE) RETURN p.date AS date, p.sources AS sources, p.unite AS unite, p.nom_piezo AS nom_piezo, p.ENTREPRISE AS ENTREPRISE, p.id AS id, p.commentaire AS commentaire, p.FILENAME AS FILENAME, p.valeur AS valeur, p.ATTACHEMENT AS ATTACHEMENT, p.substance AS substance, p.TECHNICAL_ID AS TECHNICAL_ID, p.GED_PARENT AS GED_PARENT, p.PAYS AS PAYS, p.DATE AS DATE, p.site AS site, p.valeurCensure AS valeurCensure, p.LIEN_GED AS LIEN_GED, p.substance_renomme_sirene AS substance_renomme_sirene";


    private static Map<String, String> requestMap;

    static {
        requestMap = new HashMap<>();
        requestMap.put("sirene", sirene);
    }

    static final String S3_URL = edfConfig().getString("edf.config.s3.server");
    static final String S3_accesskey = edfConfig().getString("tegg.config.s3.accesskey");
    static final String S3_secretkey = edfConfig().getString("tegg.config.s3.secretkey");
    static final String S3_path = "tmp";
    static final String S3_bucket = edfConfig().getString("tegg.config.s3.bucket");
    static final String EDF_CONFIG_TMP_PATH = edfConfig().getString("edf.config.tmp.path");

    static final S3Client s3client = S3ClientUtils.getS3Client(S3_accesskey, S3_secretkey, S3_URL);
    final static Instant instant1 = Instant.now();

    @Procedure(value = "JsonExport4SIRENE.exportJson", mode = Mode.READ)
    @Description("Export data from T_SRCOBJ_SIRENE as flat JSON without metadata")
    public Stream<ProgressInfo> export() {
        List<ProgressInfo> results = new ArrayList<>();
        final Map<String, Object> jsonExportConfig = new HashMap<>();
        jsonExportConfig.put("jsonFormat", "ARRAY_JSON");
        jsonExportConfig.put("unwindList", true);  // Évite les champs columns/meta

        requestMap.forEach((key, value) -> {
            String filename = EDF_CONFIG_TMP_PATH + key + ".json";
            try (Transaction tx = db.beginTx()) {
                ExportJson exportJson = new ExportJson();
                exportJson.apocConfig = this.apocConfig;
                exportJson.db = this.db;
                exportJson.terminationGuard = this.terminationGuard;
                exportJson.pools = this.pools;
                exportJson.tx = tx;

                Stream<ProgressInfo> progressInfoStream = exportJson.query(value, filename, jsonExportConfig);
                results.addAll(progressInfoStream.collect(Collectors.toList()));
            } catch (Exception e) {
                e.printStackTrace();
                log.error("Export failed for " + key, e);
            }
        });

        results.forEach(res -> {
            ExportToS3.exportToS3(res.file, s3client, S3_bucket, S3_path);
        });

        return results.stream();
    }

    public static class ExportResult {
        public ExportResult(String status, String filename) {
            this.status = status;
            this.filename = filename;
        }

        public String status;
        public String filename;
    }
}
