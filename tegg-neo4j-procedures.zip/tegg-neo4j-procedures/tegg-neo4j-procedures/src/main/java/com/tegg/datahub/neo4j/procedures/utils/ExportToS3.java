package com.tegg.datahub.neo4j.procedures.utils;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.File;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class ExportToS3 {

        public static void exportToS3( String filename, S3Client s3client, String s3bucket, String s3objectKey) {
            try {
                //final LocalDate dateObj = LocalDate.now();
                //final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-SS");
                //final String date = dateObj.format(formatter);

                final URI uri =new URI(filename);
                final File file = new File(uri);

                final PutObjectRequest request  = PutObjectRequest.builder().bucket(s3bucket)
                        //.key(s3objectKey + "/ExportJson/" + date + "/" + file.getName() )
                        .key(s3objectKey + "/ExportJson/"  + file.getName() )
                        .build();

                Instant start = Instant.now();
                s3client.putObject(request, Paths.get(uri));
                Instant finish = Instant.now();
                long  timeElapsed = Duration.between(start, finish).toMillis();
                System.out.println("Upload total time " + timeElapsed);
                start = Instant.now();
                Files.delete(Paths.get(uri));
                finish = Instant.now();
                timeElapsed = Duration.between(start, finish).toMillis();
                System.out.println("delete final file total time " + timeElapsed);
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

}
