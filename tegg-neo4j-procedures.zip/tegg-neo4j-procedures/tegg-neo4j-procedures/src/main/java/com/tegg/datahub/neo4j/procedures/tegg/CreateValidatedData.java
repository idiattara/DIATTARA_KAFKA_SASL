package com.tegg.datahub.neo4j.procedures.tegg;

import apoc.ApocConfig;
import apoc.Pools;
import com.tegg.datahub.neo4j.procedures.records.CreateResult;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;
import org.neo4j.procedure.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.stream.Stream;

public class CreateValidatedData {
    @Context
    public Transaction tx;

    @Context
    public GraphDatabaseService db;

    @Context
    public Log log;
    @Context
    public ApocConfig apocConfig;

    @Context
    public TerminationGuard terminationGuard;
    @Context
    public Pools pools;
    @Procedure(value = "CreateValidatedData.createValidatedData", mode = Mode.WRITE)
    @Description("Create validated data into tegg")
    public Stream<CreateResult> createValidatedData(
            @Name("url") String url,
            @Name("params") Map<String, Object> params
    ) {
        Instant start = Instant.now();
        String campagne = (String) params.get("CAMPAGNE");
        String object = (String) params.get("SRC_OBJECT_NAME");
        String user = (String) params.get("USER_NAME");
        String ged = (String) params.get("GED");
        Result result= null;
        try (Transaction tx = db.beginTx()) {
            // Load JSON data using APOC
            String loadQuery = "CALL apoc.load.json( '"+ url +"' ) YIELD value UNWIND value.properties as item \n " ;
            loadQuery = loadQuery  +  "CREATE (n:T_GED:" + "`T_SRCOBJ_" +object + "`:`T_GED_" + ged + "`" + " {TECHNICAL_ID: item.TECHNICAL_ID}) " +
                    "SET n += item return n";
             result = tx.execute(loadQuery);
            tx.commit();
            Instant finish = Instant.now();
            long timeElapsed = Duration.between(start, finish).toMillis();
            System.out.println("Total timeElapsed = "+timeElapsed);
            if (result!=null) result.close();

        }catch (Exception e){
            e.printStackTrace();
            return  Stream.of(new CreateResult("ko"));
        }

        try {
            Files.delete(Paths.get(new URI(url)));
        } catch (URISyntaxException |IOException e) {
            e.printStackTrace();
        }
        return  Stream.of(new CreateResult("ok"));
    }
}