package com.tegg.datahub.neo4j.procedures.utils;

public class TeggOntologyRelation {
    public String name;
    public String from;
    public String to;

    public String from() {
        return from;
    }
}
